import UIKit

var str = "Hello, playground"


using namespace std;

int main()
{

    string characterName = "John";
    int characterAge;
    characterAge = 35;
    cout << "There once was a man named " << characterName << endl;
    cout << "He was " << characterAge <<  endl;
    cout << "He did like the name " << characterName << endl;
    cout << "He did not like being " << characterAge << endl;


return 0
}
